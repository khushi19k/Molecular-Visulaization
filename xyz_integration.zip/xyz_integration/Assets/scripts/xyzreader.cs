using System;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using UnityEngine;

public class xyzreader : MonoBehaviour
{
    public GameObject atomprefab;
    private Dictionary<string,Color> atomc = new Dictionary<string,Color>
    {
        { "H", Color.white },
        { "O", Color.red },
        { "C", Color.grey },
        { "N", Color.blue },
        { "Cl", Color.green },
        { "S", Color.yellow },
        { "P", Color.magenta }
    };
    public string filePath;
    void Start()
    {
        xyzread(filePath);
    }
    void xyzread(string path)
{
    if (!File.Exists(path))
    {
        Debug.LogError("File not found: " + path);
        return;
    }
    string[] lines = File.ReadAllLines(path);
    int count = int.Parse(lines[0]);
    for (int i = 2; i < 2 + count; i++)
    {
        string[] parts = lines[i].Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        string element = parts[0];
        float x = float.Parse(parts[1]);
        float y = float.Parse(parts[2]);
        float z = float.Parse(parts[3]);
        plota(element, new Vector3(x, y, z));
    }
}
    void plota(string element, Vector3 position)
    {
        GameObject atom = Instantiate(atomprefab, position, Quaternion.identity);
            Renderer renderer = atom.GetComponent<Renderer>();
            renderer.material.color = atomc[element];
    }


    // // Update is called once per frame
    // void Update()
    // {
        
    // }
}
